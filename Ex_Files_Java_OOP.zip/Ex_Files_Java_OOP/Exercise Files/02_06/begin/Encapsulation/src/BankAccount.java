public class BankAccount {
    String owner;
    double balance;
}
