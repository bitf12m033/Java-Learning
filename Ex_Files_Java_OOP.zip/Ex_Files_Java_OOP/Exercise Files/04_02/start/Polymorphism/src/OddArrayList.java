public class OddArrayList extends ArrayList<Integer> {

}
