public enum TreeType {
    OAK,
    MAPLE,
    PECAN,
    WALNUT,
    PINE
}
