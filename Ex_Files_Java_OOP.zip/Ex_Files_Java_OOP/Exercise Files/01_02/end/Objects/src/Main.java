public class Main {

    public static void main(String[] args) {
        Tree myFavoriteOakTree = new Tree(25,
                5, TreeType.OAK);

        System.out.println(myFavoriteOakTree.treeType);
    }
}
