import java.awt.Color;

public class Main {

    public static void main(String[] args) {

        Color myTrunkColor = Tree.TRUNK_COLOR;
    }
}
